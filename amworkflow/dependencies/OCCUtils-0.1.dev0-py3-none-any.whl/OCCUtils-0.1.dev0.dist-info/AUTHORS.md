The OCCUtils contains code contributed by (alphabetical sort):

- Adam Lange (https://github.com/adamLange)

- Jelle Feringa (orginal author, https://github.com/jf---)

- Thomas Paviot (https://github.com/tpaviot)
